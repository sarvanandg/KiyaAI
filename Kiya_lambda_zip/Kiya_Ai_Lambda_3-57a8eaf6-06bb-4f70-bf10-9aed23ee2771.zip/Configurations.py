AMI_ID="ami-0ea451dcb1c773c7e"
INSTANCE_TYPE="g4dn.xlarge"
KEY_PAIR_NAME="kiya-poc-08-2k23"
SECURITY_GROUP_IDS=["sg-0a6c8e194acdc3cdb"]
INSTANCE_DETAILS_TABLE_NAME = "Kiya_Ai_Phase2_Instance_Details_Tb"
USER_DETAILS_TABLE_NAME = "Kiya_Ai_Phase2_User_Details_Tb"