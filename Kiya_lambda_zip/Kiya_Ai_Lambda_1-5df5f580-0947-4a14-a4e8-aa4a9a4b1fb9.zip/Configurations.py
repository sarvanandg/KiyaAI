QUEUE_URL = "https://sqs.ap-south-1.amazonaws.com/766940073591/Kiya_Ai_SQS.fifo"
USER_DETAILS_TABLE_NAME = "Kiya_Ai_Phase2_User_Details_Tb"
STATE_MACHINE_ARN = "arn:aws:states:ap-south-1:766940073591:stateMachine:Kiya_Ai_State_Machine"